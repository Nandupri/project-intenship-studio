# MLproject_FaceRecognition2 written in MATLAB
In this project, following feature extraction methods and SVM based classifiers are used for recognizing human faces under different facial expressions, pose and illumination:

 Linear and kernel SVM 

 PCA followed by linear and kernel SVM 

 LDA followed by linear and kernel SVM
